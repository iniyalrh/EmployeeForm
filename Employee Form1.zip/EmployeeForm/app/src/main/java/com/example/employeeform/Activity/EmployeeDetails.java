package com.example.employeeform.Activity;



import static com.example.employeeform.DataModel.EmployeeDetailModel.EmpID;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.employeeform.Adapter.EmpAdapter;
import com.example.employeeform.DataModel.EmployeeDetailModel;
import com.example.employeeform.R;


import java.util.ArrayList;
import java.util.List;

public class EmployeeDetails extends AppCompatActivity {
    Button btnAddEmp;
    RecyclerView rv_emp_list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_employee_details);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

       btnAddEmp = findViewById(R.id.btnAddEmp);
        rv_emp_list = findViewById(R.id.rv_emp_list);

        //tv_empId.setText

        List<EmployeeDetailModel> empList = new ArrayList<>();
        Intent intent = getIntent();
        if(intent.hasExtra("list")){
           empList = (ArrayList<EmployeeDetailModel>) getIntent().getSerializableExtra("list");

        }
        RecyclerView recyclerView= findViewById(R.id.rv_emp_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));



        //empList.add(new EmployeeDetailModel("012","Arun","arun@gmail.com","1234567890","","","123","25000"));
        //empList.add(new EmployeeDetailModel("013","Anu","anu@gmail.com","1234567891","","","1234","25000"));
        //empList.add(new EmployeeDetailModel("014","Aruna","aruna@gmail.com","1234567892","","","12345","25000"));

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        EmpAdapter adapter = new EmpAdapter(this,empList);
        recyclerView.setAdapter(adapter);

        btnAddEmp.setOnClickListener(view -> {


            Toast.makeText(this,"Added Successfully",Toast.LENGTH_SHORT).show();

            Intent intent1 = new Intent(EmployeeDetails.this, MainActivity.class);
            startActivity(intent1);

        });




    }
}