package com.example.employeeform.DataModel;

public class EmployeeModel {
}
