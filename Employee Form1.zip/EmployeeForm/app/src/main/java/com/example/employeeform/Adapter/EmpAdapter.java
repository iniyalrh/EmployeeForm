package com.example.employeeform.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.employeeform.DataModel.EmployeeDetailModel;
import com.example.employeeform.R;

import java.util.ArrayList;
import java.util.List;

public class EmpAdapter extends RecyclerView.Adapter<EmpAdapter.MyViewHolder>  {

    private List<EmployeeDetailModel>Employee =new ArrayList<>();
    private Context context;

    public EmpAdapter(Context context, List<EmployeeDetailModel>Employee){
            this.context= context;
            this.Employee= Employee;
    }



    public EmpAdapter(List<EmployeeDetailModel> empList) {

    }

    @Override
    public  MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_empdetails,parent,false);
        return new MyViewHolder(view);
    }




    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        EmployeeDetailModel  employeeDetailModel = Employee.get(position);

        holder.EmpID.setText(EmployeeDetailModel.getEmpID());
        holder.EmpName.setText(EmployeeDetailModel.getEmpName());
        holder.Department.setText(EmployeeDetailModel.getDepartment());
        holder.Designation.setText(EmployeeDetailModel.getDesignation());

    }

    @Override
    public int getItemCount() {
        return Employee.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
      TextView EmpID, EmpName, Department, Designation;




        public MyViewHolder(View Employee) {
            super(Employee);

            EmpID= Employee.findViewById(R.id.tv_empId);
            EmpName = Employee.findViewById(R.id.tv_empName);
            Department = Employee.findViewById(R.id.tv_dep);
            Designation =  Employee.findViewById(R.id.tv_des);

        }
    }
}
