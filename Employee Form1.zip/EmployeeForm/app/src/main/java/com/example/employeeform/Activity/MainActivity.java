package com.example.employeeform.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.employeeform.DataModel.EmployeeDetailModel;
import com.example.employeeform.R;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    EditText et_emp_id, et_emp_name, et_email_id, et_phone_num, et_Password, et_Salary;
    Button btnSave;
    Spinner emp_dep_spinner, emp_des_spinner;
    String department="",desig="";

    String[] Department = {"Select Department", "CSE", "MEC", "ECE"};
    String[] Designation = {"Select Designation", "Principal", "Dean", "Professor"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        et_emp_id = findViewById(R.id.et_emp_id);
        et_emp_name = findViewById(R.id.et_emp_name);
        et_email_id = findViewById(R.id.et_email_id);
        et_phone_num = findViewById(R.id.et_phone_num);
        et_Password = findViewById(R.id.et_Password);
        et_Salary = findViewById(R.id.et_Salary);
        emp_dep_spinner = findViewById(R.id.emp_dep_spinner);
        emp_des_spinner = findViewById(R.id.emp_des_spinner);
        btnSave = findViewById(R.id.btnSave);

        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,Department);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,Designation);

        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_item);
        emp_dep_spinner .setAdapter(adapter1);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        emp_des_spinner .setAdapter(adapter);

        emp_dep_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {


            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {
                if (parent.getId() == R.id.emp_dep_spinner) {

                    department = parent.getItemAtPosition(position).toString();
                   // Toast.makeText(MainActivity.this, "Selected: " + selected, Toast.LENGTH_SHORT).show();

                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }


        });

        emp_des_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {


            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {
                if (parent.getId() == R.id.emp_des_spinner) {

                    desig = parent.getItemAtPosition(position).toString();
                    //Toast.makeText(MainActivity.this, "Selected: " + selected, Toast.LENGTH_SHORT).show();

                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }


        });


        btnSave.setOnClickListener(v -> validateInputs());
    }
    private void validateInputs(){

        String EmpId = et_emp_id.getText().toString().trim();
        String EmpName = et_emp_name.getText().toString().trim();
        String EmailId = et_email_id.getText().toString().trim();
        String PhoneNumber = et_phone_num.getText().toString().trim();
        String Department = department;
        String Designation = desig;
        String Password = et_Password.getText().toString().trim();
        String Salary = et_Salary.getText().toString().trim();


        if (EmpId.isEmpty()) {
            et_emp_id.setError("EmpId is required");
            et_emp_id.requestFocus();
            return;
        }
        if (EmpName.isEmpty()) {
            et_emp_name.setError("EmpName is required");
            et_emp_name.requestFocus();
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(EmailId).matches()) {
            et_email_id.setError("EmailId is required");
            et_email_id.requestFocus();
            return;
        }

        if(PhoneNumber.length()<10){
            et_phone_num.setError("PhoneNumber is required");
            et_phone_num.requestFocus();
            return;
        }

        if (emp_dep_spinner.getSelectedItem().toString().trim().equals("Select department")) {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }

        if (emp_des_spinner.getSelectedItem().toString().trim().equals("Select Designation")) {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }

        if(PhoneNumber.length()<10){
            et_phone_num.setError("PhoneNumber is required");
            et_phone_num.requestFocus();
            return;
        }

        if(Password.isEmpty()){
            et_Password.setError("Password is required");
            et_Password.requestFocus();
            return;
        }
        if(Password.length()<5){
            et_Password.setError("Password must be at least 5 characters");
            et_Password.requestFocus();
            return;
        }

        if (Salary.isEmpty()) {
            et_Salary.setError("Salary is required");
            et_Salary.requestFocus();
            return;
        }

        List<EmployeeDetailModel> empList = new ArrayList<>();

        empList.add(new EmployeeDetailModel("EmpID : "+ EmpId,"EmpName : "+ EmpName, "EmailId : " + EmailId, "PhoneNumber : " + PhoneNumber,"Department : " + Department,"Designation : " + Designation,"Password : " + Password,"Salary : " + Salary));



        Toast.makeText(this, "Saved Successfully!", Toast.LENGTH_SHORT).show();


        Intent intent = new Intent(MainActivity.this, EmployeeDetails.class);
        intent.putExtra("list",(Serializable) empList);
        startActivity(intent);
        finish();


    }



            }



